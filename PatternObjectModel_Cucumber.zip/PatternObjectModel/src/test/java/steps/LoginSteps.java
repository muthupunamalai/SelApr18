package steps;

import java.sql.Driver;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import bsh.commands.dir;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	/*public static RemoteWebDriver driver;
	@Given("open the browser")
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		 driver = new ChromeDriver();
	}
	@And("max the browser")
	public void maxBrowser() {
		driver.manage().window().maximize();
	}
	@And("set time out")
	public void setTimeOut() {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	@And("enter the URL")
	public void launchURL() {
		driver.get("http://leaftaps.com/opentaps");
	}
	@And("enter the userName as (.*)")
	public void enterUserName(String data) {
		driver.findElementById("username").sendKeys(data);
	}
	@And("enter the Password as (.*)")
	public void enterPassword(String data) {
		driver.findElementById("password").sendKeys(data);
	}
	@When("click on the login button")
	public void clickLogin() {
		driver.findElementByClassName("decorativeSubmit").click();
	}
	@Then("verify login is success")
	public void verifyLogin() {
		System.out.println("login is success");
	}
	
	@Then("verify login is failed")
	public void verifyLoginForFailed() {
		System.out.println("verify login is failed");
	}
	
	
	
	
	
	
	*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
